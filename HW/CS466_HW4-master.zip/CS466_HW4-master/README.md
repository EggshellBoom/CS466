# CS466_HW4

Requirements: recent Python (2 or 3) installation with matplotlib, pandas, numpy and scipy.
